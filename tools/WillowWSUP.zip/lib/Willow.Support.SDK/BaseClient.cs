


namespace Willow.Support.SDK
{
	public abstract class BaseClient
	{
	}
}
