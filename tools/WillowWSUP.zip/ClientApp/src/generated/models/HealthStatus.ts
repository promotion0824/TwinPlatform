/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export enum HealthStatus {
    '_0' = 0,
    '_1' = 1,
    '_2' = 2,
}
