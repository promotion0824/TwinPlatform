/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export enum LifeCycleState {
    UNKNOWN = 'Unknown',
    EMPTY = 'Empty',
    COMMISSIONING = 'Commissioning',
    LIVE = 'Live',
    DECOMMISSIONING = 'Decommissioning',
    DECOMMISSIONED = 'Decommissioned',
}
