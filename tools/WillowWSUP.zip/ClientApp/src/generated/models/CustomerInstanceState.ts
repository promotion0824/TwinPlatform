/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { CustomerInstance } from './CustomerInstance';
import type { HealthStatus } from './HealthStatus';
export type CustomerInstanceState = {
    customerInstance?: CustomerInstance;
    statuses?: Array<HealthStatus> | null;
    status?: HealthStatus;
};

