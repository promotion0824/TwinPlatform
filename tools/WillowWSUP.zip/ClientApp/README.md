
TO GENERATE CLIENT

npx openapi --input http://localhost:5000/swagger/v1/swagger.json --output ./src/generated

