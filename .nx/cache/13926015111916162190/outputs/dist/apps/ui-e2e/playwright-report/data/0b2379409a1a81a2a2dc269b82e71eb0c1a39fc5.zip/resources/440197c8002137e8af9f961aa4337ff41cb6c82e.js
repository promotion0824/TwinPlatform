(self["webpackChunkdesign_system"] = self["webpackChunkdesign_system"] || []).push([["libs_ui_src_lib_overlays_Tooltip_Tooltip_stories_tsx"],{

/***/ "./libs/ui/src/lib/overlays/Tooltip/Tooltip.stories.tsx":
/*!**************************************************************!*\
  !*** ./libs/ui/src/lib/overlays/Tooltip/Tooltip.stories.tsx ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   DefaultOpen: () => (/* binding */ DefaultOpen),
/* harmony export */   Disabled: () => (/* binding */ Disabled),
/* harmony export */   Inline: () => (/* binding */ Inline),
/* harmony export */   Multiline: () => (/* binding */ Multiline),
/* harmony export */   Placement: () => (/* binding */ Placement),
/* harmony export */   PlacementWithArrow: () => (/* binding */ PlacementWithArrow),
/* harmony export */   Playground: () => (/* binding */ Playground),
/* harmony export */   TriggerOnFocus: () => (/* binding */ TriggerOnFocus),
/* harmony export */   __namedExportsOrder: () => (/* binding */ __namedExportsOrder),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var E_Workspace_Willow_TwinPlatform_design_system_node_modules_babel_runtime_helpers_taggedTemplateLiteralLoose_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/taggedTemplateLiteralLoose.js */ "./node_modules/@babel/runtime/helpers/taggedTemplateLiteralLoose.js");
/* harmony import */ var E_Workspace_Willow_TwinPlatform_design_system_node_modules_babel_runtime_helpers_taggedTemplateLiteralLoose_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(E_Workspace_Willow_TwinPlatform_design_system_node_modules_babel_runtime_helpers_taggedTemplateLiteralLoose_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! styled-components */ "./node_modules/styled-components/dist/styled-components.browser.esm.js");
/* harmony import */ var _storybookUtils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../storybookUtils */ "./libs/ui/src/storybookUtils/index.tsx");
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! . */ "./libs/ui/src/lib/overlays/Tooltip/index.tsx");
/* harmony import */ var _buttons_Button__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../buttons/Button */ "./libs/ui/src/lib/buttons/Button/index.tsx");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");

var _this = undefined,
  _templateObject,
  _templateObject2,
  _templateObject3;

var _jsxFileName = "E:\\Workspace\\Willow\\TwinPlatform\\design-system\\libs\\ui\\src\\lib\\overlays\\Tooltip\\Tooltip.stories.tsx",
  _ = function _(t) {
    return t;
  },
  _t,
  _t2,
  _t3;





var meta = {
  title: 'Tooltip',
  component: ___WEBPACK_IMPORTED_MODULE_3__.Tooltip
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (meta);
var SingleTooltipDecorator = function SingleTooltipDecorator(Story) {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_StyledStoryFlexContainer, {
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(Story, {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 23,
      columnNumber: 5
    }, _this)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 17,
    columnNumber: 3
  }, _this);
};
var Playground = {
  render: function render() {
    return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(___WEBPACK_IMPORTED_MODULE_3__.Tooltip, {
      label: "Tooltip Content",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_buttons_Button__WEBPACK_IMPORTED_MODULE_4__.Button, {
        children: "Trigger"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 30,
        columnNumber: 7
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 29,
      columnNumber: 5
    }, _this);
  },
  decorators: [SingleTooltipDecorator]
};
var StyledWrapper = styled_components__WEBPACK_IMPORTED_MODULE_6__["default"].div(_t || (_t = _(_templateObject || (_templateObject = E_Workspace_Willow_TwinPlatform_design_system_node_modules_babel_runtime_helpers_taggedTemplateLiteralLoose_js__WEBPACK_IMPORTED_MODULE_0___default()(["\n  padding-top: 40px;\n  margin: auto;\n  width: fit-content;\n  display: grid;\n  grid-template-columns: 80px repeat(3, 150px) 100px;\n  grid-template-rows: repeat(5, 60px);\n  grid-template-areas:\n    '. top-start top top-end .'\n    'left-start . . . right-start'\n    'left . . . right'\n    'left-end . . . right-end'\n    '. bottom-start bottom bottom-end .';\n"])))));
var Placement = {
  render: function render() {
    return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.Fragment, {
      children: ['top-start', 'top', 'top-end', 'left-start', 'left', 'left-end', 'right-start', 'right', 'right-end', 'bottom-start', 'bottom', 'bottom-end'].map(function (placement) {
        return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_StyledDiv, {
          $_css: placement,
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(___WEBPACK_IMPORTED_MODULE_3__.Tooltip, {
            label: "Tooltip Content",
            position: placement,
            opened: true,
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_buttons_Button__WEBPACK_IMPORTED_MODULE_4__.Button, {
              children: placement
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 77,
              columnNumber: 13
            }, _this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 76,
            columnNumber: 11
          }, _this)
        }, placement, false, {
          fileName: _jsxFileName,
          lineNumber: 70,
          columnNumber: 9
        }, _this);
      })
    }, void 0, false);
  },
  decorators: [function (Story) {
    return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(StyledWrapper, {
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(Story, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 86,
        columnNumber: 9
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 85,
      columnNumber: 7
    }, _this);
  }]
};
var PlacementWithArrow = {
  render: function render() {
    return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.Fragment, {
      children: ['top-start', 'top', 'top-end', 'left-start', 'left', 'left-end', 'right-start', 'right', 'right-end', 'bottom-start', 'bottom', 'bottom-end'].map(function (placement) {
        return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_StyledDiv2, {
          $_css2: placement,
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(___WEBPACK_IMPORTED_MODULE_3__.Tooltip, {
            withArrow: true,
            label: "Tooltip Content",
            position: placement,
            opened: true,
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_buttons_Button__WEBPACK_IMPORTED_MODULE_4__.Button, {
              children: placement
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 123,
              columnNumber: 13
            }, _this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 117,
            columnNumber: 11
          }, _this)
        }, placement, false, {
          fileName: _jsxFileName,
          lineNumber: 111,
          columnNumber: 9
        }, _this);
      })
    }, void 0, false);
  },
  decorators: [function (Story) {
    return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(StyledWrapper, {
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(Story, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 132,
        columnNumber: 9
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 131,
      columnNumber: 7
    }, _this);
  }]
};
var DefaultOpen = {
  render: function render() {
    return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(___WEBPACK_IMPORTED_MODULE_3__.Tooltip, {
      label: "Tooltip Content",
      opened: true,
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_buttons_Button__WEBPACK_IMPORTED_MODULE_4__.Button, {
        children: "Trigger"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 141,
        columnNumber: 7
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 140,
      columnNumber: 5
    }, _this);
  },
  decorators: [SingleTooltipDecorator]
};
var TriggerOnFocus = {
  render: function render() {
    return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(___WEBPACK_IMPORTED_MODULE_3__.Tooltip, {
      label: "Tooltip Content",
      events: {
        hover: false,
        focus: true,
        touch: false
      },
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_buttons_Button__WEBPACK_IMPORTED_MODULE_4__.Button, {
        children: "Trigger"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 153,
        columnNumber: 7
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 149,
      columnNumber: 5
    }, _this);
  },
  decorators: [SingleTooltipDecorator]
};
var Disabled = {
  render: function render() {
    return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(___WEBPACK_IMPORTED_MODULE_3__.Tooltip, {
      label: "Tooltip Content",
      disabled: true,
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_buttons_Button__WEBPACK_IMPORTED_MODULE_4__.Button, {
        children: "Trigger"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 162,
        columnNumber: 7
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 161,
      columnNumber: 5
    }, _this);
  }
};
var Multiline = {
  render: function render() {
    return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(___WEBPACK_IMPORTED_MODULE_3__.Tooltip, {
      multiline: true,
      width: 220,
      label: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_buttons_Button__WEBPACK_IMPORTED_MODULE_4__.Button, {
        children: "Trigger"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 174,
        columnNumber: 7
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 169,
      columnNumber: 5
    }, _this);
  },
  decorators: [function (Story) {
    return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_StyledStoryFlexContainer2, {
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(Story, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 185,
        columnNumber: 9
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 179,
      columnNumber: 7
    }, _this);
  }]
};
var Inline = {
  render: function render() {
    return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_StyledP, {
      children: ["Lorem ipsum dolor sit amet, consectetur adipiscing elit,", ' ', /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(___WEBPACK_IMPORTED_MODULE_3__.Tooltip, {
        label: "Tooltip Content",
        inline: true,
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)("mark", {
          children: "inline trigger"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 196,
          columnNumber: 9
        }, _this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 195,
        columnNumber: 7
      }, _this), ' ', "sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 193,
      columnNumber: 5
    }, _this);
  }
};
var _StyledStoryFlexContainer = (0,styled_components__WEBPACK_IMPORTED_MODULE_6__["default"])(_storybookUtils__WEBPACK_IMPORTED_MODULE_2__.StoryFlexContainer)(_t2 || (_t2 = _(_templateObject2 || (_templateObject2 = E_Workspace_Willow_TwinPlatform_design_system_node_modules_babel_runtime_helpers_taggedTemplateLiteralLoose_js__WEBPACK_IMPORTED_MODULE_0___default()(["\n      height: 50px;\n      align-items: end;\n    "])))));
var _StyledDiv = (0,styled_components__WEBPACK_IMPORTED_MODULE_6__["default"])("div")(function (p) {
  return {
    gridArea: p.$_css
  };
});
var _StyledDiv2 = (0,styled_components__WEBPACK_IMPORTED_MODULE_6__["default"])("div")(function (p) {
  return {
    gridArea: p.$_css2
  };
});
var _StyledStoryFlexContainer2 = (0,styled_components__WEBPACK_IMPORTED_MODULE_6__["default"])(_storybookUtils__WEBPACK_IMPORTED_MODULE_2__.StoryFlexContainer)(_t3 || (_t3 = _(_templateObject3 || (_templateObject3 = E_Workspace_Willow_TwinPlatform_design_system_node_modules_babel_runtime_helpers_taggedTemplateLiteralLoose_js__WEBPACK_IMPORTED_MODULE_0___default()(["\n          height: 120px;\n          align-items: end;\n        "])))));
var _StyledP = /*#__PURE__*/(0,styled_components__WEBPACK_IMPORTED_MODULE_6__["default"])("p").withConfig({
  displayName: "Tooltipstories___StyledP",
  componentId: "sc-14gb435-0"
})({
  color: 'white'
});
Playground.parameters = {
  ...Playground.parameters,
  docs: {
    ...Playground.parameters?.docs,
    source: {
      originalSource: "{\n  render: () => <Tooltip label=\"Tooltip Content\">\r\n      <Button>Trigger</Button>\r\n    </Tooltip>,\n  decorators: [SingleTooltipDecorator]\n}",
      ...Playground.parameters?.docs?.source
    }
  }
};
Placement.parameters = {
  ...Placement.parameters,
  docs: {
    ...Placement.parameters?.docs,
    source: {
      originalSource: "{\n  render: () => <>\r\n      {(['top-start', 'top', 'top-end', 'left-start', 'left', 'left-end', 'right-start', 'right', 'right-end', 'bottom-start', 'bottom', 'bottom-end'] as const).map(placement => <div key={placement} css={{\n      gridArea: placement\n    }}>\r\n          <Tooltip label=\"Tooltip Content\" position={placement} opened>\r\n            <Button>{placement}</Button>\r\n          </Tooltip>\r\n        </div>)}\r\n    </>,\n  decorators: [Story => <StyledWrapper>\r\n        <Story />\r\n      </StyledWrapper>]\n}",
      ...Placement.parameters?.docs?.source
    }
  }
};
PlacementWithArrow.parameters = {
  ...PlacementWithArrow.parameters,
  docs: {
    ...PlacementWithArrow.parameters?.docs,
    source: {
      originalSource: "{\n  render: () => <>\r\n      {(['top-start', 'top', 'top-end', 'left-start', 'left', 'left-end', 'right-start', 'right', 'right-end', 'bottom-start', 'bottom', 'bottom-end'] as const).map(placement => <div key={placement} css={{\n      gridArea: placement\n    }}>\r\n          <Tooltip withArrow label=\"Tooltip Content\" position={placement} opened>\r\n            <Button>{placement}</Button>\r\n          </Tooltip>\r\n        </div>)}\r\n    </>,\n  decorators: [Story => <StyledWrapper>\r\n        <Story />\r\n      </StyledWrapper>]\n}",
      ...PlacementWithArrow.parameters?.docs?.source
    }
  }
};
DefaultOpen.parameters = {
  ...DefaultOpen.parameters,
  docs: {
    ...DefaultOpen.parameters?.docs,
    source: {
      originalSource: "{\n  render: () => <Tooltip label=\"Tooltip Content\" opened>\r\n      <Button>Trigger</Button>\r\n    </Tooltip>,\n  decorators: [SingleTooltipDecorator]\n}",
      ...DefaultOpen.parameters?.docs?.source
    }
  }
};
TriggerOnFocus.parameters = {
  ...TriggerOnFocus.parameters,
  docs: {
    ...TriggerOnFocus.parameters?.docs,
    source: {
      originalSource: "{\n  render: () => <Tooltip label=\"Tooltip Content\" events={{\n    hover: false,\n    focus: true,\n    touch: false\n  }}>\r\n      <Button>Trigger</Button>\r\n    </Tooltip>,\n  decorators: [SingleTooltipDecorator]\n}",
      ...TriggerOnFocus.parameters?.docs?.source
    }
  }
};
Disabled.parameters = {
  ...Disabled.parameters,
  docs: {
    ...Disabled.parameters?.docs,
    source: {
      originalSource: "{\n  render: () => <Tooltip label=\"Tooltip Content\" disabled>\r\n      <Button>Trigger</Button>\r\n    </Tooltip>\n}",
      ...Disabled.parameters?.docs?.source
    }
  }
};
Multiline.parameters = {
  ...Multiline.parameters,
  docs: {
    ...Multiline.parameters?.docs,
    source: {
      originalSource: "{\n  render: () => <Tooltip multiline width={220} label=\"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.\">\r\n      <Button>Trigger</Button>\r\n    </Tooltip>,\n  decorators: [Story => <StoryFlexContainer css={css`\n          height: 120px;\n          align-items: end;\n        `}>\r\n        <Story />\r\n      </StoryFlexContainer>]\n}",
      ...Multiline.parameters?.docs?.source
    }
  }
};
Inline.parameters = {
  ...Inline.parameters,
  docs: {
    ...Inline.parameters?.docs,
    source: {
      originalSource: "{\n  render: () => <p css={{\n    color: 'white'\n  }}>\r\n      Lorem ipsum dolor sit amet, consectetur adipiscing elit,{' '}\r\n      <Tooltip label=\"Tooltip Content\" inline>\r\n        <mark>inline trigger</mark>\r\n      </Tooltip>{' '}\r\n      sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.\r\n    </p>\n}",
      ...Inline.parameters?.docs?.source
    }
  }
};;const __namedExportsOrder = ["Playground","Placement","PlacementWithArrow","DefaultOpen","TriggerOnFocus","Disabled","Multiline","Inline"];

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/taggedTemplateLiteralLoose.js":
/*!***************************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/taggedTemplateLiteralLoose.js ***!
  \***************************************************************************/
/***/ ((module) => {

function _taggedTemplateLiteralLoose(e, t) {
  return t || (t = e.slice(0)), e.raw = t, e;
}
module.exports = _taggedTemplateLiteralLoose, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ })

}]);
//# sourceMappingURL=libs_ui_src_lib_overlays_Tooltip_Tooltip_stories_tsx.iframe.bundle.js.map