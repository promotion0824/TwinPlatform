"use strict";
(self["webpackChunkdesign_system"] = self["webpackChunkdesign_system"] || []).push([["Flex-Flex-stories"],{

/***/ "./libs/ui/src/storybookUtils/FlexDecorator.tsx":
/*!******************************************************!*\
  !*** ./libs/ui/src/storybookUtils/FlexDecorator.tsx ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FlexDecorator: () => (/* binding */ FlexDecorator)
/* harmony export */ });
/* harmony import */ var _StoryContainers__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./StoryContainers */ "./libs/ui/src/storybookUtils/StoryContainers.tsx");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
var _this = undefined;
var _jsxFileName = "E:\\Workspace\\Willow\\TwinPlatform\\design-system\\libs\\ui\\src\\storybookUtils\\FlexDecorator.tsx";


/** A horizontal flex container decorator for arranging multiple components
 * in a single story. The container will restrict the width so that
 * the screenshot size is minimal. The container contains a test id which could be
 * selected via `storybook.storyContainer`in Playwright.
 */

var FlexDecorator = function FlexDecorator(Story) {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(_StoryContainers__WEBPACK_IMPORTED_MODULE_0__.StoryFlexContainer, {
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(Story, {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 10,
      columnNumber: 5
    }, _this)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 9,
    columnNumber: 3
  }, _this);
};
try {
    // @ts-ignore
    FlexDecorator.displayName = "FlexDecorator";
    // @ts-ignore
    FlexDecorator.__docgenInfo = { "description": "A horizontal flex container decorator for arranging multiple components\nin a single story. The container will restrict the width so that\nthe screenshot size is minimal. The container contains a test id which could be\nselected via `storybook.storyContainer`in Playwright.", "displayName": "FlexDecorator", "props": {} };
    // @ts-ignore
    if (typeof STORYBOOK_REACT_CLASSES !== "undefined")
        // @ts-ignore
        STORYBOOK_REACT_CLASSES["libs/ui/src/storybookUtils/FlexDecorator.tsx#FlexDecorator"] = { docgenInfo: FlexDecorator.__docgenInfo, name: "FlexDecorator", path: "libs/ui/src/storybookUtils/FlexDecorator.tsx#FlexDecorator" };
}
catch (__react_docgen_typescript_loader_error) { }

/***/ }),

/***/ "./libs/ui/src/storybookUtils/MemoryRouterDecorator.tsx":
/*!**************************************************************!*\
  !*** ./libs/ui/src/storybookUtils/MemoryRouterDecorator.tsx ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MemoryRouterDecorator: () => (/* binding */ MemoryRouterDecorator)
/* harmony export */ });
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-router-dom */ "./node_modules/react-router/dist/index.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
var _this = undefined;
var _jsxFileName = "E:\\Workspace\\Willow\\TwinPlatform\\design-system\\libs\\ui\\src\\storybookUtils\\MemoryRouterDecorator.tsx";


var MemoryRouterDecorator = function MemoryRouterDecorator(Story) {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_router_dom__WEBPACK_IMPORTED_MODULE_1__.MemoryRouter, {
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Story, {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 5,
      columnNumber: 5
    }, _this)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 4,
    columnNumber: 3
  }, _this);
};
try {
    // @ts-ignore
    MemoryRouterDecorator.displayName = "MemoryRouterDecorator";
    // @ts-ignore
    MemoryRouterDecorator.__docgenInfo = { "description": "", "displayName": "MemoryRouterDecorator", "props": {} };
    // @ts-ignore
    if (typeof STORYBOOK_REACT_CLASSES !== "undefined")
        // @ts-ignore
        STORYBOOK_REACT_CLASSES["libs/ui/src/storybookUtils/MemoryRouterDecorator.tsx#MemoryRouterDecorator"] = { docgenInfo: MemoryRouterDecorator.__docgenInfo, name: "MemoryRouterDecorator", path: "libs/ui/src/storybookUtils/MemoryRouterDecorator.tsx#MemoryRouterDecorator" };
}
catch (__react_docgen_typescript_loader_error) { }

/***/ }),

/***/ "./libs/ui/src/storybookUtils/StoryContainers.tsx":
/*!********************************************************!*\
  !*** ./libs/ui/src/storybookUtils/StoryContainers.tsx ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   StoryFlexContainer: () => (/* binding */ StoryFlexContainer),
/* harmony export */   storyContainerTestId: () => (/* binding */ storyContainerTestId)
/* harmony export */ });
/* harmony import */ var core_js_modules_es_object_assign_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.object.assign.js */ "./node_modules/core-js/modules/es.object.assign.js");
/* harmony import */ var core_js_modules_es_object_assign_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_assign_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! styled-components */ "./node_modules/styled-components/dist/styled-components.browser.esm.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
var _this = undefined;


var _jsxFileName = "E:\\Workspace\\Willow\\TwinPlatform\\design-system\\libs\\ui\\src\\storybookUtils\\StoryContainers.tsx";


/** Reminder: to reuse the same test id if you add more story Containers. */
var storyContainerTestId = 'story-container';

/** A horizontal flex container for arranging multiple components in a
 * single story. It will restrict the width so that the screenshot size is minimal.
 * And it contains a test id which could be selected via `storybook.storyContainer`
 * in Playwright.
 */
var StoryFlexContainer = function StoryFlexContainer(props) {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(_StyledDiv, Object.assign({
    "data-testid": storyContainerTestId
  }, props), void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 12,
    columnNumber: 3
  }, _this);
};
var _StyledDiv = /*#__PURE__*/(0,styled_components__WEBPACK_IMPORTED_MODULE_2__["default"])("div").withConfig({
  displayName: "StoryContainers___StyledDiv",
  componentId: "sc-1s1xytk-0"
})({
  display: 'flex',
  gap: '1rem',
  width: 'fit-content'
});
try {
    // @ts-ignore
    storyContainerTestId.displayName = "storyContainerTestId";
    // @ts-ignore
    storyContainerTestId.__docgenInfo = { "description": "Reminder: to reuse the same test id if you add more story Containers.", "displayName": "storyContainerTestId", "props": {} };
    // @ts-ignore
    if (typeof STORYBOOK_REACT_CLASSES !== "undefined")
        // @ts-ignore
        STORYBOOK_REACT_CLASSES["libs/ui/src/storybookUtils/StoryContainers.tsx#storyContainerTestId"] = { docgenInfo: storyContainerTestId.__docgenInfo, name: "storyContainerTestId", path: "libs/ui/src/storybookUtils/StoryContainers.tsx#storyContainerTestId" };
}
catch (__react_docgen_typescript_loader_error) { }
try {
    // @ts-ignore
    StoryFlexContainer.displayName = "StoryFlexContainer";
    // @ts-ignore
    StoryFlexContainer.__docgenInfo = { "description": "A horizontal flex container for arranging multiple components in a\nsingle story. It will restrict the width so that the screenshot size is minimal.\nAnd it contains a test id which could be selected via `storybook.storyContainer`\nin Playwright.", "displayName": "StoryFlexContainer", "props": {} };
    // @ts-ignore
    if (typeof STORYBOOK_REACT_CLASSES !== "undefined")
        // @ts-ignore
        STORYBOOK_REACT_CLASSES["libs/ui/src/storybookUtils/StoryContainers.tsx#StoryFlexContainer"] = { docgenInfo: StoryFlexContainer.__docgenInfo, name: "StoryFlexContainer", path: "libs/ui/src/storybookUtils/StoryContainers.tsx#StoryFlexContainer" };
}
catch (__react_docgen_typescript_loader_error) { }

/***/ }),

/***/ "./libs/ui/src/storybookUtils/TreeDecorator.tsx":
/*!******************************************************!*\
  !*** ./libs/ui/src/storybookUtils/TreeDecorator.tsx ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   TreeDecorator: () => (/* binding */ TreeDecorator)
/* harmony export */ });
/* harmony import */ var _StoryContainers__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./StoryContainers */ "./libs/ui/src/storybookUtils/StoryContainers.tsx");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
var _this = undefined;
var _jsxFileName = "E:\\Workspace\\Willow\\TwinPlatform\\design-system\\libs\\ui\\src\\storybookUtils\\TreeDecorator.tsx";


var TreeDecorator = function TreeDecorator(Story) {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
    "data-testid": _StoryContainers__WEBPACK_IMPORTED_MODULE_0__.storyContainerTestId,
    style: {
      width: 260
    },
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(Story, {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 5,
      columnNumber: 5
    }, _this)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 4,
    columnNumber: 3
  }, _this);
};
try {
    // @ts-ignore
    TreeDecorator.displayName = "TreeDecorator";
    // @ts-ignore
    TreeDecorator.__docgenInfo = { "description": "", "displayName": "TreeDecorator", "props": {} };
    // @ts-ignore
    if (typeof STORYBOOK_REACT_CLASSES !== "undefined")
        // @ts-ignore
        STORYBOOK_REACT_CLASSES["libs/ui/src/storybookUtils/TreeDecorator.tsx#TreeDecorator"] = { docgenInfo: TreeDecorator.__docgenInfo, name: "TreeDecorator", path: "libs/ui/src/storybookUtils/TreeDecorator.tsx#TreeDecorator" };
}
catch (__react_docgen_typescript_loader_error) { }

/***/ }),

/***/ "./libs/ui/src/storybookUtils/hiddenPage.tsx":
/*!***************************************************!*\
  !*** ./libs/ui/src/storybookUtils/hiddenPage.tsx ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   hiddenPrefix: () => (/* binding */ hiddenPrefix),
/* harmony export */   makeHiddenStoryTitle: () => (/* binding */ makeHiddenStoryTitle)
/* harmony export */ });
/** The prefix that used to determine whether to hide an element */
// same as in /libs/ui/.storybook/manager-head.html
var hiddenPrefix = 'hidden-test-components';

/**
 * @returns the story title that will be used to identify whether to hide the story
 */
var makeHiddenStoryTitle = function makeHiddenStoryTitle(storyTitle) {
  return hiddenPrefix + '-' + storyTitle;
};
try {
    // @ts-ignore
    hiddenPrefix.displayName = "hiddenPrefix";
    // @ts-ignore
    hiddenPrefix.__docgenInfo = { "description": "The prefix that used to determine whether to hide an element", "displayName": "hiddenPrefix", "props": {} };
    // @ts-ignore
    if (typeof STORYBOOK_REACT_CLASSES !== "undefined")
        // @ts-ignore
        STORYBOOK_REACT_CLASSES["libs/ui/src/storybookUtils/hiddenPage.tsx#hiddenPrefix"] = { docgenInfo: hiddenPrefix.__docgenInfo, name: "hiddenPrefix", path: "libs/ui/src/storybookUtils/hiddenPage.tsx#hiddenPrefix" };
}
catch (__react_docgen_typescript_loader_error) { }
try {
    // @ts-ignore
    makeHiddenStoryTitle.displayName = "makeHiddenStoryTitle";
    // @ts-ignore
    makeHiddenStoryTitle.__docgenInfo = { "description": "", "displayName": "makeHiddenStoryTitle", "props": {} };
    // @ts-ignore
    if (typeof STORYBOOK_REACT_CLASSES !== "undefined")
        // @ts-ignore
        STORYBOOK_REACT_CLASSES["libs/ui/src/storybookUtils/hiddenPage.tsx#makeHiddenStoryTitle"] = { docgenInfo: makeHiddenStoryTitle.__docgenInfo, name: "makeHiddenStoryTitle", path: "libs/ui/src/storybookUtils/hiddenPage.tsx#makeHiddenStoryTitle" };
}
catch (__react_docgen_typescript_loader_error) { }

/***/ }),

/***/ "./libs/ui/src/storybookUtils/index.tsx":
/*!**********************************************!*\
  !*** ./libs/ui/src/storybookUtils/index.tsx ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FlexDecorator: () => (/* reexport safe */ _FlexDecorator__WEBPACK_IMPORTED_MODULE_0__.FlexDecorator),
/* harmony export */   MemoryRouterDecorator: () => (/* reexport safe */ _MemoryRouterDecorator__WEBPACK_IMPORTED_MODULE_2__.MemoryRouterDecorator),
/* harmony export */   SourceLink: () => (/* reexport safe */ _util_storybook__WEBPACK_IMPORTED_MODULE_5__.SourceLink),
/* harmony export */   StoryFlexContainer: () => (/* reexport safe */ _StoryContainers__WEBPACK_IMPORTED_MODULE_3__.StoryFlexContainer),
/* harmony export */   SupportStatus: () => (/* reexport safe */ _util_storybook__WEBPACK_IMPORTED_MODULE_5__.SupportStatus),
/* harmony export */   TreeDecorator: () => (/* reexport safe */ _TreeDecorator__WEBPACK_IMPORTED_MODULE_4__.TreeDecorator),
/* harmony export */   hiddenPrefix: () => (/* reexport safe */ _hiddenPage__WEBPACK_IMPORTED_MODULE_1__.hiddenPrefix),
/* harmony export */   makeHiddenStoryTitle: () => (/* reexport safe */ _hiddenPage__WEBPACK_IMPORTED_MODULE_1__.makeHiddenStoryTitle),
/* harmony export */   storyContainerTestId: () => (/* reexport safe */ _StoryContainers__WEBPACK_IMPORTED_MODULE_3__.storyContainerTestId)
/* harmony export */ });
/* harmony import */ var _FlexDecorator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./FlexDecorator */ "./libs/ui/src/storybookUtils/FlexDecorator.tsx");
/* harmony import */ var _hiddenPage__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./hiddenPage */ "./libs/ui/src/storybookUtils/hiddenPage.tsx");
/* harmony import */ var _MemoryRouterDecorator__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./MemoryRouterDecorator */ "./libs/ui/src/storybookUtils/MemoryRouterDecorator.tsx");
/* harmony import */ var _StoryContainers__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./StoryContainers */ "./libs/ui/src/storybookUtils/StoryContainers.tsx");
/* harmony import */ var _TreeDecorator__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./TreeDecorator */ "./libs/ui/src/storybookUtils/TreeDecorator.tsx");
/* harmony import */ var _util_storybook__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./util-storybook */ "./libs/ui/src/storybookUtils/util-storybook.tsx");






try {
    // @ts-ignore
    FlexDecorator.displayName = "FlexDecorator";
    // @ts-ignore
    FlexDecorator.__docgenInfo = { "description": "A horizontal flex container decorator for arranging multiple components\nin a single story. The container will restrict the width so that\nthe screenshot size is minimal. The container contains a test id which could be\nselected via `storybook.storyContainer`in Playwright.", "displayName": "FlexDecorator", "props": {} };
    // @ts-ignore
    if (typeof STORYBOOK_REACT_CLASSES !== "undefined")
        // @ts-ignore
        STORYBOOK_REACT_CLASSES["libs/ui/src/storybookUtils/index.tsx#FlexDecorator"] = { docgenInfo: FlexDecorator.__docgenInfo, name: "FlexDecorator", path: "libs/ui/src/storybookUtils/index.tsx#FlexDecorator" };
}
catch (__react_docgen_typescript_loader_error) { }
try {
    // @ts-ignore
    hiddenPrefix.displayName = "hiddenPrefix";
    // @ts-ignore
    hiddenPrefix.__docgenInfo = { "description": "The prefix that used to determine whether to hide an element", "displayName": "hiddenPrefix", "props": {} };
    // @ts-ignore
    if (typeof STORYBOOK_REACT_CLASSES !== "undefined")
        // @ts-ignore
        STORYBOOK_REACT_CLASSES["libs/ui/src/storybookUtils/index.tsx#hiddenPrefix"] = { docgenInfo: hiddenPrefix.__docgenInfo, name: "hiddenPrefix", path: "libs/ui/src/storybookUtils/index.tsx#hiddenPrefix" };
}
catch (__react_docgen_typescript_loader_error) { }
try {
    // @ts-ignore
    makeHiddenStoryTitle.displayName = "makeHiddenStoryTitle";
    // @ts-ignore
    makeHiddenStoryTitle.__docgenInfo = { "description": "", "displayName": "makeHiddenStoryTitle", "props": {} };
    // @ts-ignore
    if (typeof STORYBOOK_REACT_CLASSES !== "undefined")
        // @ts-ignore
        STORYBOOK_REACT_CLASSES["libs/ui/src/storybookUtils/index.tsx#makeHiddenStoryTitle"] = { docgenInfo: makeHiddenStoryTitle.__docgenInfo, name: "makeHiddenStoryTitle", path: "libs/ui/src/storybookUtils/index.tsx#makeHiddenStoryTitle" };
}
catch (__react_docgen_typescript_loader_error) { }
try {
    // @ts-ignore
    MemoryRouterDecorator.displayName = "MemoryRouterDecorator";
    // @ts-ignore
    MemoryRouterDecorator.__docgenInfo = { "description": "", "displayName": "MemoryRouterDecorator", "props": {} };
    // @ts-ignore
    if (typeof STORYBOOK_REACT_CLASSES !== "undefined")
        // @ts-ignore
        STORYBOOK_REACT_CLASSES["libs/ui/src/storybookUtils/index.tsx#MemoryRouterDecorator"] = { docgenInfo: MemoryRouterDecorator.__docgenInfo, name: "MemoryRouterDecorator", path: "libs/ui/src/storybookUtils/index.tsx#MemoryRouterDecorator" };
}
catch (__react_docgen_typescript_loader_error) { }
try {
    // @ts-ignore
    storyContainerTestId.displayName = "storyContainerTestId";
    // @ts-ignore
    storyContainerTestId.__docgenInfo = { "description": "Reminder: to reuse the same test id if you add more story Containers.", "displayName": "storyContainerTestId", "props": {} };
    // @ts-ignore
    if (typeof STORYBOOK_REACT_CLASSES !== "undefined")
        // @ts-ignore
        STORYBOOK_REACT_CLASSES["libs/ui/src/storybookUtils/index.tsx#storyContainerTestId"] = { docgenInfo: storyContainerTestId.__docgenInfo, name: "storyContainerTestId", path: "libs/ui/src/storybookUtils/index.tsx#storyContainerTestId" };
}
catch (__react_docgen_typescript_loader_error) { }
try {
    // @ts-ignore
    StoryFlexContainer.displayName = "StoryFlexContainer";
    // @ts-ignore
    StoryFlexContainer.__docgenInfo = { "description": "A horizontal flex container for arranging multiple components in a\nsingle story. It will restrict the width so that the screenshot size is minimal.\nAnd it contains a test id which could be selected via `storybook.storyContainer`\nin Playwright.", "displayName": "StoryFlexContainer", "props": {} };
    // @ts-ignore
    if (typeof STORYBOOK_REACT_CLASSES !== "undefined")
        // @ts-ignore
        STORYBOOK_REACT_CLASSES["libs/ui/src/storybookUtils/index.tsx#StoryFlexContainer"] = { docgenInfo: StoryFlexContainer.__docgenInfo, name: "StoryFlexContainer", path: "libs/ui/src/storybookUtils/index.tsx#StoryFlexContainer" };
}
catch (__react_docgen_typescript_loader_error) { }
try {
    // @ts-ignore
    TreeDecorator.displayName = "TreeDecorator";
    // @ts-ignore
    TreeDecorator.__docgenInfo = { "description": "", "displayName": "TreeDecorator", "props": {} };
    // @ts-ignore
    if (typeof STORYBOOK_REACT_CLASSES !== "undefined")
        // @ts-ignore
        STORYBOOK_REACT_CLASSES["libs/ui/src/storybookUtils/index.tsx#TreeDecorator"] = { docgenInfo: TreeDecorator.__docgenInfo, name: "TreeDecorator", path: "libs/ui/src/storybookUtils/index.tsx#TreeDecorator" };
}
catch (__react_docgen_typescript_loader_error) { }
try {
    // @ts-ignore
    SupportStatus.displayName = "SupportStatus";
    // @ts-ignore
    SupportStatus.__docgenInfo = { "description": "", "displayName": "SupportStatus", "props": { "__filename": { "defaultValue": null, "description": "", "name": "__filename", "required": true, "type": { "name": "string" } } } };
    // @ts-ignore
    if (typeof STORYBOOK_REACT_CLASSES !== "undefined")
        // @ts-ignore
        STORYBOOK_REACT_CLASSES["libs/ui/src/storybookUtils/index.tsx#SupportStatus"] = { docgenInfo: SupportStatus.__docgenInfo, name: "SupportStatus", path: "libs/ui/src/storybookUtils/index.tsx#SupportStatus" };
}
catch (__react_docgen_typescript_loader_error) { }
try {
    // @ts-ignore
    SourceLink.displayName = "SourceLink";
    // @ts-ignore
    SourceLink.__docgenInfo = { "description": "", "displayName": "SourceLink", "props": { "name": { "defaultValue": null, "description": "", "name": "name", "required": true, "type": { "name": "string" } }, "groupName": { "defaultValue": null, "description": "", "name": "groupName", "required": true, "type": { "name": "string" } } } };
    // @ts-ignore
    if (typeof STORYBOOK_REACT_CLASSES !== "undefined")
        // @ts-ignore
        STORYBOOK_REACT_CLASSES["libs/ui/src/storybookUtils/index.tsx#SourceLink"] = { docgenInfo: SourceLink.__docgenInfo, name: "SourceLink", path: "libs/ui/src/storybookUtils/index.tsx#SourceLink" };
}
catch (__react_docgen_typescript_loader_error) { }

/***/ }),

/***/ "./libs/ui/src/storybookUtils/util-storybook.tsx":
/*!*******************************************************!*\
  !*** ./libs/ui/src/storybookUtils/util-storybook.tsx ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SourceLink: () => (/* binding */ SourceLink),
/* harmony export */   SupportStatus: () => (/* binding */ SupportStatus)
/* harmony export */ });
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
var _this = undefined;

var _jsxFileName = "E:\\Workspace\\Willow\\TwinPlatform\\design-system\\libs\\ui\\src\\storybookUtils\\util-storybook.tsx";

// Not used anywhere, consider remove after confirmation
var SupportStatus = function SupportStatus(_ref) {
  var __filename = _ref.__filename;
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("h2", {
      className: "sbdocs sbdocs-h2 css-idch3x",
      children: "Supported behavior (WIP, ignore)"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 4,
      columnNumber: 5
    }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("p", {
      className: "sbdocs sbdocs-p css-1p8ieni",
      children: "You can use this component in the below situations. If you wish to use this outside of these, you must read our testing page (link) and add a test case that describes your use case, to be covered by our automated test suite."
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 7,
      columnNumber: 5
    }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("ul", {
      className: "sbdocs sbdocs-ul css-122ju8q",
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("li", {
        className: "sbdocs sbdocs-li css-1ta8r1d",
        children: "List of tests"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 15,
        columnNumber: 7
      }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("li", {
        className: "sbdocs sbdocs-li css-1ta8r1d",
        children: "that tell us what we can do with it"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 16,
        columnNumber: 7
      }, _this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 14,
      columnNumber: 5
    }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("p", {
      className: "sbdocs sbdocs-p css-1p8ieni",
      children: "Further tested behavior:"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 21,
      columnNumber: 5
    }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("ul", {
      className: "sbdocs sbdocs-ul css-122ju8q",
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("li", {
        className: "sbdocs sbdocs-li css-1ta8r1d",
        children: "In an accordion"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 24,
        columnNumber: 7
      }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("li", {
        className: "sbdocs sbdocs-li css-1ta8r1d",
        children: "More tests"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 25,
        columnNumber: 7
      }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("li", {
        className: "sbdocs sbdocs-li css-1ta8r1d",
        children: "That are more boring or we don't want to display to people"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 26,
        columnNumber: 7
      }, _this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 23,
      columnNumber: 5
    }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("p", {
      className: "sbdocs sbdocs-p css-1p8ieni",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("em", {
        children: ["Meta: data computed for ", __filename]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 32,
        columnNumber: 7
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 31,
      columnNumber: 5
    }, _this)]
  }, void 0, true);
};
var SourceLink = function SourceLink(_ref2) {
  var name = _ref2.name,
    groupName = _ref2.groupName;
  var repoUrlBase = 'https://github.com/WillowInc/TwinPlatform/blob/main/design-system/libs/ui/src/lib/';
  var repoTsxLink = repoUrlBase + groupName + '/' + name + '/';
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("p", {
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("a", {
      href: repoTsxLink,
      target: "_blank",
      rel: "noreferrer",
      children: "View source"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 49,
      columnNumber: 7
    }, _this)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 48,
    columnNumber: 5
  }, _this);
};
try {
    // @ts-ignore
    SupportStatus.displayName = "SupportStatus";
    // @ts-ignore
    SupportStatus.__docgenInfo = { "description": "", "displayName": "SupportStatus", "props": { "__filename": { "defaultValue": null, "description": "", "name": "__filename", "required": true, "type": { "name": "string" } } } };
    // @ts-ignore
    if (typeof STORYBOOK_REACT_CLASSES !== "undefined")
        // @ts-ignore
        STORYBOOK_REACT_CLASSES["libs/ui/src/storybookUtils/util-storybook.tsx#SupportStatus"] = { docgenInfo: SupportStatus.__docgenInfo, name: "SupportStatus", path: "libs/ui/src/storybookUtils/util-storybook.tsx#SupportStatus" };
}
catch (__react_docgen_typescript_loader_error) { }
try {
    // @ts-ignore
    SourceLink.displayName = "SourceLink";
    // @ts-ignore
    SourceLink.__docgenInfo = { "description": "", "displayName": "SourceLink", "props": { "name": { "defaultValue": null, "description": "", "name": "name", "required": true, "type": { "name": "string" } }, "groupName": { "defaultValue": null, "description": "", "name": "groupName", "required": true, "type": { "name": "string" } } } };
    // @ts-ignore
    if (typeof STORYBOOK_REACT_CLASSES !== "undefined")
        // @ts-ignore
        STORYBOOK_REACT_CLASSES["libs/ui/src/storybookUtils/util-storybook.tsx#SourceLink"] = { docgenInfo: SourceLink.__docgenInfo, name: "SourceLink", path: "libs/ui/src/storybookUtils/util-storybook.tsx#SourceLink" };
}
catch (__react_docgen_typescript_loader_error) { }

/***/ })

}]);
//# sourceMappingURL=Flex-Flex-stories.iframe.bundle.js.map