"use strict";
(self["webpackChunkdesign_system"] = self["webpackChunkdesign_system"] || []).push([["libs_ui_src_lib_layout_Flex_Flex_stories_tsx"],{

/***/ "./libs/ui/src/lib/layout/Flex/Flex.stories.tsx":
/*!******************************************************!*\
  !*** ./libs/ui/src/lib/layout/Flex/Flex.stories.tsx ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Align: () => (/* binding */ Align),
/* harmony export */   ColumnGap: () => (/* binding */ ColumnGap),
/* harmony export */   Direction: () => (/* binding */ Direction),
/* harmony export */   Gap: () => (/* binding */ Gap),
/* harmony export */   Justify: () => (/* binding */ Justify),
/* harmony export */   Playground: () => (/* binding */ Playground),
/* harmony export */   PolymorphicAndDifferentChildrenWidth: () => (/* binding */ PolymorphicAndDifferentChildrenWidth),
/* harmony export */   RowGap: () => (/* binding */ RowGap),
/* harmony export */   Wrap: () => (/* binding */ Wrap),
/* harmony export */   __namedExportsOrder: () => (/* binding */ __namedExportsOrder),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! styled-components */ "./node_modules/styled-components/dist/styled-components.browser.esm.js");
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! . */ "./libs/ui/src/lib/layout/Flex/index.tsx");
/* harmony import */ var _buttons_Button__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../buttons/Button */ "./libs/ui/src/lib/buttons/Button/index.tsx");
/* harmony import */ var _storybookUtils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../storybookUtils */ "./libs/ui/src/storybookUtils/index.tsx");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
var _this = undefined;
var _jsxFileName = "E:\\Workspace\\Willow\\TwinPlatform\\design-system\\libs\\ui\\src\\lib\\layout\\Flex\\Flex.stories.tsx";





var meta = {
  title: 'Flex',
  component: ___WEBPACK_IMPORTED_MODULE_0__.Flex,
  decorators: [_storybookUtils__WEBPACK_IMPORTED_MODULE_2__.FlexDecorator]
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (meta);
var StyledButton = /*#__PURE__*/(0,styled_components__WEBPACK_IMPORTED_MODULE_4__["default"])(_buttons_Button__WEBPACK_IMPORTED_MODULE_1__.Button).withConfig({
  displayName: "Flexstories__StyledButton",
  componentId: "sc-19azx9z-0"
})(["display:block;"]);
var Playground = {
  render: function render() {
    return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(___WEBPACK_IMPORTED_MODULE_0__.Flex, {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(StyledButton, {
        kind: "primary",
        children: "First"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 24,
        columnNumber: 7
      }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(StyledButton, {
        kind: "primary",
        children: "Second"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 25,
        columnNumber: 7
      }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(StyledButton, {
        kind: "primary",
        children: "Third"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 26,
        columnNumber: 7
      }, _this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 23,
      columnNumber: 5
    }, _this);
  }
};
var Gap = {
  render: function render() {
    return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(___WEBPACK_IMPORTED_MODULE_0__.Flex, {
      gap: "s32",
      wrap: "wrap",
      w: 260,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(StyledButton, {
        kind: "primary",
        children: "Button"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 34,
        columnNumber: 7
      }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(StyledButton, {
        kind: "primary",
        children: "Button"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 35,
        columnNumber: 7
      }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(StyledButton, {
        kind: "primary",
        children: "Button"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 36,
        columnNumber: 7
      }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(StyledButton, {
        kind: "primary",
        children: "Button"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 37,
        columnNumber: 7
      }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(StyledButton, {
        kind: "primary",
        children: "Button"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 38,
        columnNumber: 7
      }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(StyledButton, {
        kind: "primary",
        children: "Button"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 39,
        columnNumber: 7
      }, _this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 33,
      columnNumber: 5
    }, _this);
  }
};
var ColumnGap = {
  render: function render() {
    return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(___WEBPACK_IMPORTED_MODULE_0__.Flex, {
      columnGap: "s32",
      wrap: "wrap",
      w: 260,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(StyledButton, {
        kind: "primary",
        children: "Button"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 47,
        columnNumber: 7
      }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(StyledButton, {
        kind: "primary",
        children: "Button"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 48,
        columnNumber: 7
      }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(StyledButton, {
        kind: "primary",
        children: "Button"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 49,
        columnNumber: 7
      }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(StyledButton, {
        kind: "primary",
        children: "Button"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 50,
        columnNumber: 7
      }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(StyledButton, {
        kind: "primary",
        children: "Button"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 51,
        columnNumber: 7
      }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(StyledButton, {
        kind: "primary",
        children: "Button"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 52,
        columnNumber: 7
      }, _this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 46,
      columnNumber: 5
    }, _this);
  }
};
var RowGap = {
  render: function render() {
    return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(___WEBPACK_IMPORTED_MODULE_0__.Flex, {
      rowGap: "s32",
      wrap: "wrap",
      w: 260,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(StyledButton, {
        kind: "primary",
        children: "Button"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 60,
        columnNumber: 7
      }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(StyledButton, {
        kind: "primary",
        children: "Button"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 61,
        columnNumber: 7
      }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(StyledButton, {
        kind: "primary",
        children: "Button"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 62,
        columnNumber: 7
      }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(StyledButton, {
        kind: "primary",
        children: "Button"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 63,
        columnNumber: 7
      }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(StyledButton, {
        kind: "primary",
        children: "Button"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 64,
        columnNumber: 7
      }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(StyledButton, {
        kind: "primary",
        children: "Button"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 65,
        columnNumber: 7
      }, _this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 59,
      columnNumber: 5
    }, _this);
  }
};
var Align = {
  render: function render() {
    return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(___WEBPACK_IMPORTED_MODULE_0__.Flex, {
      align: "self-end",
      h: 100,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(StyledButton, {
        kind: "primary",
        children: "Button"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 73,
        columnNumber: 7
      }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(StyledButton, {
        kind: "primary",
        children: "Button"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 74,
        columnNumber: 7
      }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(StyledButton, {
        kind: "primary",
        children: "Button"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 75,
        columnNumber: 7
      }, _this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 72,
      columnNumber: 5
    }, _this);
  }
};
var Justify = {
  render: function render() {
    return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(___WEBPACK_IMPORTED_MODULE_0__.Flex, {
      justify: "flex-end",
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(StyledButton, {
        kind: "primary",
        children: "Button"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 83,
        columnNumber: 7
      }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(StyledButton, {
        kind: "primary",
        children: "Button"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 84,
        columnNumber: 7
      }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(StyledButton, {
        kind: "primary",
        children: "Button"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 85,
        columnNumber: 7
      }, _this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 82,
      columnNumber: 5
    }, _this);
  }
};
var Direction = {
  render: function render() {
    return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(___WEBPACK_IMPORTED_MODULE_0__.Flex, {
      direction: "column",
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(StyledButton, {
        kind: "primary",
        children: "Button"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 93,
        columnNumber: 7
      }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(StyledButton, {
        kind: "primary",
        children: "Button"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 94,
        columnNumber: 7
      }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(StyledButton, {
        kind: "primary",
        children: "Button"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 95,
        columnNumber: 7
      }, _this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 92,
      columnNumber: 5
    }, _this);
  }
};
var Wrap = {
  render: function render() {
    return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(___WEBPACK_IMPORTED_MODULE_0__.Flex, {
      w: 260,
      wrap: "wrap",
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(StyledButton, {
        kind: "primary",
        children: "Button"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 103,
        columnNumber: 7
      }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(StyledButton, {
        kind: "primary",
        children: "Button"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 104,
        columnNumber: 7
      }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(StyledButton, {
        kind: "primary",
        children: "Button"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 105,
        columnNumber: 7
      }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(StyledButton, {
        kind: "primary",
        children: "Button"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 106,
        columnNumber: 7
      }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(StyledButton, {
        kind: "primary",
        children: "Button"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 107,
        columnNumber: 7
      }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(StyledButton, {
        kind: "primary",
        children: "Button"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 108,
        columnNumber: 7
      }, _this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 102,
      columnNumber: 5
    }, _this);
  }
};
var PolymorphicAndDifferentChildrenWidth = {
  render: function render() {
    return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(___WEBPACK_IMPORTED_MODULE_0__.Flex, {
      component: "section",
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(StyledButton, {
        kind: "primary",
        children: "First"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 116,
        columnNumber: 7
      }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(StyledButton, {
        kind: "primary",
        children: "Second"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 117,
        columnNumber: 7
      }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(StyledButton, {
        kind: "primary",
        children: "Third"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 118,
        columnNumber: 7
      }, _this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 115,
      columnNumber: 5
    }, _this);
  }
};
Playground.parameters = {
  ...Playground.parameters,
  docs: {
    ...Playground.parameters?.docs,
    source: {
      originalSource: "{\n  render: () => <Flex>\r\n      <StyledButton kind=\"primary\">First</StyledButton>\r\n      <StyledButton kind=\"primary\">Second</StyledButton>\r\n      <StyledButton kind=\"primary\">Third</StyledButton>\r\n    </Flex>\n}",
      ...Playground.parameters?.docs?.source
    }
  }
};
Gap.parameters = {
  ...Gap.parameters,
  docs: {
    ...Gap.parameters?.docs,
    source: {
      originalSource: "{\n  render: () => <Flex gap=\"s32\" wrap=\"wrap\" w={260}>\r\n      <StyledButton kind=\"primary\">Button</StyledButton>\r\n      <StyledButton kind=\"primary\">Button</StyledButton>\r\n      <StyledButton kind=\"primary\">Button</StyledButton>\r\n      <StyledButton kind=\"primary\">Button</StyledButton>\r\n      <StyledButton kind=\"primary\">Button</StyledButton>\r\n      <StyledButton kind=\"primary\">Button</StyledButton>\r\n    </Flex>\n}",
      ...Gap.parameters?.docs?.source
    }
  }
};
ColumnGap.parameters = {
  ...ColumnGap.parameters,
  docs: {
    ...ColumnGap.parameters?.docs,
    source: {
      originalSource: "{\n  render: () => <Flex columnGap=\"s32\" wrap=\"wrap\" w={260}>\r\n      <StyledButton kind=\"primary\">Button</StyledButton>\r\n      <StyledButton kind=\"primary\">Button</StyledButton>\r\n      <StyledButton kind=\"primary\">Button</StyledButton>\r\n      <StyledButton kind=\"primary\">Button</StyledButton>\r\n      <StyledButton kind=\"primary\">Button</StyledButton>\r\n      <StyledButton kind=\"primary\">Button</StyledButton>\r\n    </Flex>\n}",
      ...ColumnGap.parameters?.docs?.source
    }
  }
};
RowGap.parameters = {
  ...RowGap.parameters,
  docs: {
    ...RowGap.parameters?.docs,
    source: {
      originalSource: "{\n  render: () => <Flex rowGap=\"s32\" wrap=\"wrap\" w={260}>\r\n      <StyledButton kind=\"primary\">Button</StyledButton>\r\n      <StyledButton kind=\"primary\">Button</StyledButton>\r\n      <StyledButton kind=\"primary\">Button</StyledButton>\r\n      <StyledButton kind=\"primary\">Button</StyledButton>\r\n      <StyledButton kind=\"primary\">Button</StyledButton>\r\n      <StyledButton kind=\"primary\">Button</StyledButton>\r\n    </Flex>\n}",
      ...RowGap.parameters?.docs?.source
    }
  }
};
Align.parameters = {
  ...Align.parameters,
  docs: {
    ...Align.parameters?.docs,
    source: {
      originalSource: "{\n  render: () => <Flex align=\"self-end\" h={100}>\r\n      <StyledButton kind=\"primary\">Button</StyledButton>\r\n      <StyledButton kind=\"primary\">Button</StyledButton>\r\n      <StyledButton kind=\"primary\">Button</StyledButton>\r\n    </Flex>\n}",
      ...Align.parameters?.docs?.source
    }
  }
};
Justify.parameters = {
  ...Justify.parameters,
  docs: {
    ...Justify.parameters?.docs,
    source: {
      originalSource: "{\n  render: () => <Flex justify=\"flex-end\">\r\n      <StyledButton kind=\"primary\">Button</StyledButton>\r\n      <StyledButton kind=\"primary\">Button</StyledButton>\r\n      <StyledButton kind=\"primary\">Button</StyledButton>\r\n    </Flex>\n}",
      ...Justify.parameters?.docs?.source
    }
  }
};
Direction.parameters = {
  ...Direction.parameters,
  docs: {
    ...Direction.parameters?.docs,
    source: {
      originalSource: "{\n  render: () => <Flex direction=\"column\">\r\n      <StyledButton kind=\"primary\">Button</StyledButton>\r\n      <StyledButton kind=\"primary\">Button</StyledButton>\r\n      <StyledButton kind=\"primary\">Button</StyledButton>\r\n    </Flex>\n}",
      ...Direction.parameters?.docs?.source
    }
  }
};
Wrap.parameters = {
  ...Wrap.parameters,
  docs: {
    ...Wrap.parameters?.docs,
    source: {
      originalSource: "{\n  render: () => <Flex w={260} wrap=\"wrap\">\r\n      <StyledButton kind=\"primary\">Button</StyledButton>\r\n      <StyledButton kind=\"primary\">Button</StyledButton>\r\n      <StyledButton kind=\"primary\">Button</StyledButton>\r\n      <StyledButton kind=\"primary\">Button</StyledButton>\r\n      <StyledButton kind=\"primary\">Button</StyledButton>\r\n      <StyledButton kind=\"primary\">Button</StyledButton>\r\n    </Flex>\n}",
      ...Wrap.parameters?.docs?.source
    }
  }
};
PolymorphicAndDifferentChildrenWidth.parameters = {
  ...PolymorphicAndDifferentChildrenWidth.parameters,
  docs: {
    ...PolymorphicAndDifferentChildrenWidth.parameters?.docs,
    source: {
      originalSource: "{\n  render: () => <Flex component=\"section\">\r\n      <StyledButton kind=\"primary\">First</StyledButton>\r\n      <StyledButton kind=\"primary\">Second</StyledButton>\r\n      <StyledButton kind=\"primary\">Third</StyledButton>\r\n    </Flex>\n}",
      ...PolymorphicAndDifferentChildrenWidth.parameters?.docs?.source
    }
  }
};;const __namedExportsOrder = ["Playground","Gap","ColumnGap","RowGap","Align","Justify","Direction","Wrap","PolymorphicAndDifferentChildrenWidth"];

/***/ })

}]);
//# sourceMappingURL=libs_ui_src_lib_layout_Flex_Flex_stories_tsx.iframe.bundle.js.map