# Introduction 
This repository contains Rules that can be edited offline (as JSON) and can then be uploaded to the Rules Engine.

We can create directories of shared rules that can be copied to any customer environment, these should be categoried by topic (e.g. occupancy, HVAC, HVAC/Comfort, HVAC/Reliability, ...).

We can also create directories of rules for a specific customer environment.

The Rules Engine has an import and export feature allowing individual rules to be uploaded or for all rules to be downloaded as a ZIP. Ultmately we will edit in Rules Engine and then export to this repository.

*Note: The ID of a Rule is important. An import with the same ID will overwrite an existing rule.*

# Real Estate
This directory is considered the base set of rules that have been validated to be applied to all customers. Some rules have both a metric and an imperial version in order to account for differences in how the parameters are defined. When both versions are imported to a customer environment, the user should deselect the rule instances that aren't applicable for the given rule.

# Customer
This directory contains rules that have been developed and applied for a specific customer.

## Microsoft
This directory contains a set of rules that were considered the base but have not been fully validated. It contains rules that may not be fully validated but capture scenarios that Microsoft's real estate organization have established. Once fully validated, this directory will be completely superseded by the Real Estate directory.

# Prototype
This directory is junk folder containing some of the prototype rules that have been used during development of the rules engine. Some of them bind quite well to 1MW, some bind to MSFT 121/122, but many of them do not bind successfully.


# Contribute
To contribute, create a branch, make your changes, push them up and then create a pull request for approval which will be merged into main.

# Futures
In the long term, this import / export capability will allow us to publish rule libraries either publicly or in closed user groups. To get there we need to keep improving the way we model in DTDL so that rules can always bind using _only_ the DTDL models and properties. Rules Engine supports binding by tags and BACNET name fragments but this capability does not create rules that can be easily copied from one environment to another and longer-term, use of it should be phased out.

# Contacts
Ian Mercer, Rick Szcodronski